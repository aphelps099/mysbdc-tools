"""
Sheets → JSON converter for NorCal Lender Database.

Usage:
  1. Export your Google Sheet as CSV (File → Download → CSV)
  2. Run: python sheets_to_json.py lender_database.csv -o lenders.json

Or point it at the xlsx directly:
  python sheets_to_json.py norcal_lender_database.xlsx -o lenders.json
"""

import argparse, json, sys
import pandas as pd

def parse_counties(raw: str) -> list[str]:
    if not raw or pd.isna(raw):
        return []
    return [c.strip() for c in str(raw).split(",") if c.strip()]

def row_to_lender(row) -> dict:
    fico = row.get("Min FICO", "")
    if pd.isna(fico) or fico == "" or fico == 0:
        fico_val = None
    else:
        fico_val = int(float(fico))

    return {
        "id": int(row["ID"]) if not pd.isna(row.get("ID", "")) else 0,
        "name": str(row.get("Institution Name", "")),
        "category": str(row.get("Category", "")),
        "subcategory": str(row.get("Subcategory", "")),
        "loanTypes": str(row.get("Loan Types & Products", "")),
        "minFICO": fico_val,
        "maxLoanSize": str(row.get("Max Loan Size", "") or ""),
        "minRevenue": str(row.get("Min Revenue", "") or ""),
        "minTimeInBusiness": str(row.get("Min Time in Business", "") or ""),
        "targetProfile": str(row.get("Target Borrower Profile", "") or ""),
        "geographicFocus": str(row.get("Geographic Focus", "") or ""),
        "countiesServed": parse_counties(row.get("Counties Served", "")),
        "contact": {
            "name": str(row.get("Contact Name", "") or ""),
            "phone": str(row.get("Contact Phone", "") or ""),
            "email": str(row.get("Contact Email", "") or ""),
            "website": str(row.get("Website", "") or ""),
        },
        "notes": str(row.get("Notes", "") or ""),
    }

def main():
    parser = argparse.ArgumentParser(description="Convert lender spreadsheet to JSON")
    parser.add_argument("input", help="Path to CSV or XLSX file")
    parser.add_argument("-o", "--output", default="lenders.json", help="Output JSON path")
    parser.add_argument("--pretty", action="store_true", default=True)
    args = parser.parse_args()

    if args.input.endswith(".csv"):
        df = pd.read_csv(args.input)
    else:
        df = pd.read_excel(args.input, sheet_name="Lender Database")

    lenders = [row_to_lender(row) for _, row in df.iterrows()]

    with open(args.output, "w") as f:
        json.dump(lenders, f, indent=2 if args.pretty else None, ensure_ascii=False)

    print(f"Exported {len(lenders)} lenders → {args.output}")

if __name__ == "__main__":
    main()
