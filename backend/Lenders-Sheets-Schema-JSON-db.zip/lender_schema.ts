// ── NorCal SBDC Lender Database Schema ──
// Use this as the contract between your data source (Sheets/CSV) and your frontend.

export interface Lender {
  id: number;
  name: string;
  category: LenderCategory;
  subcategory: string;
  loanTypes: string;
  minFICO: number | null;       // null = no minimum / holistic underwriting
  maxLoanSize: string;           // kept as string for flexibility ("$5M", "$5.5M (SBA portion)")
  minRevenue: string;
  minTimeInBusiness: string;
  targetProfile: string;
  geographicFocus: string;
  countiesServed: string[];      // normalized array for filtering
  contact: {
    name: string;
    phone: string;
    email: string;
    website: string;
  };
  notes: string;
}

export type LenderCategory =
  | "Commercial & Regional Bank"
  | "Credit Union"
  | "CDFI & Mission-Driven"
  | "State-Supported (CalCAP/FDC)"
  | "SBA 504 CDC"
  | "Private Equity & Venture Debt"
  | "Alternative & FinTech";

export interface TriageTier {
  tier: string;
  minFICO: string;
  requiredHistory: string;
  targetRevenue: string;
  useCase: string;
  speedToFunding: string;
}

// ── Google Sheets Integration ──
//
// Option A: Published CSV (simplest)
//   1. File → Share → Publish to web → Sheet 1 → CSV
//   2. Fetch the published URL, parse with Papa Parse
//
// Option B: Sheets API (more control)
//   const SHEET_ID = "your-sheet-id";
//   const API_KEY = "your-api-key";
//   const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/Lender%20Database?key=${API_KEY}`;
//
// Either way, map the response rows to this Lender interface.
